CREATE TABLE CONVENIENT_us_metadata(
	"Province/State" varchar2(255) primary key,
	"Admin2" varchar2(255),
	"Population" int,
	"Lat" decimal(10,10),
	"Long" decimal(10,10)
);