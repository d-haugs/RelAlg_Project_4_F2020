CREATE TABLE CONVENIENT_global_metadata(
	"Country/Region" varchar2(255) primary key,
	"Province/State" varchar2(255),
	"Lat" decimal(10,10),
	"Long" decimal(10,10)
);